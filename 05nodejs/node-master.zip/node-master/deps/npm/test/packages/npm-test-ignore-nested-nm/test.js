fs = require('fs')
fs.statSync(__dirname + '/lib/node_modules/foo')
