npm-root(3) -- Display npm root
===============================

## SYNOPSIS

    npm.commands.root(args, callback)

## DESCRIPTION

Print the effective `node_modules` folder to standard out.

'args' is never used and callback is never called with data.
'args' must be present or things will break.

This function is not useful programmatically.
