# Introduction

JavaScript is a dynamically typed scripting language universally used to
script web content in browsers.

Its specification by ECMA can be found [here](http://www.ecma-international.org/publications/standards/Ecma-262.htm).