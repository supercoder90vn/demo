'use strict';

/**
 * Chat socket tests
 */
describe('Chat Socket Tests:', function () {
  this.timeout(10000);

  // TODO: Add chat socket tests
});
