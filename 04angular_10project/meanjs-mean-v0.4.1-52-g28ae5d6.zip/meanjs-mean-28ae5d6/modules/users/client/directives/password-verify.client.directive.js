'use strict';

angular.module('users')
  .directive('passwordVerify', function() {
    return {
      require: 'ngModel',
      scope: {
        passwordVerify: '='
      },
      link: function(scope, element, attrs, modelCtrl) {
        scope.$watch(function() {
          var combined;
          if (scope.passwordVerify || modelCtrl.$viewValue) {
            combined = scope.passwordVerify + '_' + modelCtrl.$viewValue;
          }
          return combined;
        }, function(value) {
          if (value) {
            modelCtrl.$parsers.unshift(function(viewValue) {
              var origin = scope.passwordVerify;
              if (origin !== viewValue) {
                modelCtrl.$setValidity('passwordVerify', false);
                return undefined;
              } else {
                modelCtrl.$setValidity('passwordVerify', true);
                return viewValue;
              }
            });
          }
        });
     }
    };
});
